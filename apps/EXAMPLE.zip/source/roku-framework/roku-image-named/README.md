# roku-image-named
This is Roku BrightScript Code to load images pby using the name of the image or Url Path 
